The following files were generated for 'instr_mem' in directory
D:\comeoncedifficult\Pipelined-2_stall\Pipelined-2\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * instr_mem.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * instr_mem.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * instr_mem.asy
   * instr_mem.mif
   * instr_mem.ngc
   * instr_mem.sym
   * instr_mem.v
   * instr_mem.veo

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * instr_mem.veo

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * instr_mem_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * instr_mem.gise
   * instr_mem.xise

Deliver Readme:
   Readme file for the IP.

   * instr_mem_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * instr_mem_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

